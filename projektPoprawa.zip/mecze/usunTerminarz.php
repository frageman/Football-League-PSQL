<?php 

    include('../db_connect.php');
    $query = "SET SEARCH_PATH TO projektBD; Delete from mecz;";
    echo "Wykonane polecenie: $query<br/>";

    $res = pg_query($db, $query);
    $note = pg_last_notice($db);

    if(!$res){
        echo "BŁĄD BAZY DANYCH:<br>";
        echo pg_last_error($db)."<br>";
        }
    else if($note ){
        echo "$note<br>";
    }
    else{
    header("Location: /~6pogwizd/projekt_bd/indexSedzia.php");
    exit;
    }        
    echo "<a href=\"/~6pogwizd/projekt_bd/indexSedzia.php\">powrót do strony głównej</a> ";

?>